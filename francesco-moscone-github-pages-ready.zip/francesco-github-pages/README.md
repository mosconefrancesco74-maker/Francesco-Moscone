# Francesco Moscone personal website — master offline build

This package is designed for one manual upload when Netlify credits are available again.

## Improvements included
- local hero image (no dependency on Brunel/LinkedIn image hotlinks)
- local MP4 video and poster image
- stronger mobile layout
- SEO title, description, canonical URL, Open Graph and Twitter metadata
- Person structured data for search engines
- clearer economist/public-intellectual positioning
- press archive retained
- responsive navigation and mobile-first typography

## Upload later
Use the existing Netlify project `francesco-moscone` (the project connected to francescomoscone.com), not `cosmic-bublanina-3af604`.
